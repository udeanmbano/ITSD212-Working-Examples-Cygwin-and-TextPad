#include<iostream>
#include<string>
using namespace std;

#ifndef petType_HEADER
#define petType_HEADER
class petType
{
public:
	virtual void print(); //virtual function
	petType(string n = "");
private:
	string name;
};
petType::petType(string n)
{
	name = n;
}
void petType:: print()
{
	cout << "Name: " << name;
}
#endif