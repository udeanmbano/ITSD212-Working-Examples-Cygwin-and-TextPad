#include <iostream>
#include "Example.h"

using namespace std;

example::example(){
}

void example::setFunction(){
}

void example::getFunction(){
}

void example :: printFunction() {

	cout << "The quick brown fox, jumps over the lazy dog" << endl;
}