#include <iostream>
#include <string>

using namespace std;

class Square
{
private:
	int width;
	int length;

public:
	Square(int w, int l)
	{
		this->width = w;
		this->length = l;
	}

	void setDimension(int w, int l)
	{
		this->width = w;
		this->length = l;
	}

	void printArea()
	{
		cout << " The area of  " << width << " and " << length << " is : " << width*length << endl;
	}

};

int main()
{
	Square s1(4, 4);
	s1.printArea();


	Square s2 = s1;
	//Square s2(s1);
	s2.printArea();

	s1.setDimension(5, 5);
	s1.printArea();

	s2.printArea();

	return 0;
}