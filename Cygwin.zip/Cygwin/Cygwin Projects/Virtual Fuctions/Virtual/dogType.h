#include "petType.h"
#ifndef dogType_HEADER
#define dogType_HEADER
class dogType : public petType
{
public:
	void print();
	void setBreed(string b = "");
	dogType(string n = "", string b = "");
private:
	string breed;
};

dogType:: dogType(string n, string b) :petType(n){
	breed = b;
}
void dogType::setBreed(string k)
{
	breed = k;
}
void dogType :: print()
{
petType:: print();
	cout << ", Breed: " << breed << endl;
}
#endif