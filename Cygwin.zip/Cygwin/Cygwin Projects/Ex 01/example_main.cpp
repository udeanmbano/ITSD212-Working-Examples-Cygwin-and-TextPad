#include<iostream>

#include "example.h"
using namespace std;
int main (){

	example anObject;

	anObject.printFunction();

	return 0;
}