#include <iostream>
#ifndef Example_H
#define Example_H

class example
{
     private :
     	int a_var;
     	int new_var;

     public :
     	example();
     	int getFunction();
     	void setFunction(int par_x);
     	void printFunction();
};

#endif