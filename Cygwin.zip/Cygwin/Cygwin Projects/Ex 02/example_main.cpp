#include "example.h"

int main (){

	example anObject;

//	example 1
//	anObject.setFunction(25);


//	example 2
//	int new_var;
//	new_var = anObject.getFunction();
//	anObject.setFunction(new_var);


//	exmaple 3
	anObject.setFunction(anObject.getFunction());


	anObject.printFunction();

	return 0;
}