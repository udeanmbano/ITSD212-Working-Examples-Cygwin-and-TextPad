#include <iostream>
using namespace std;

int main(){

	int x = 20;

	// memory address of x
	cout << "memory address of x : " << &x << endl;

	// pointer ptr
	int *ptr;

	ptr = &x;
	cout << "value of ptr : " << ptr << endl;

	// dereference
	cout << "dereferenced ptr : " << &ptr << endl;


	x = x + 5;
	//x = 20 + 5
	//x = 25

	x = *ptr + 5;
	// x = 25 + 5
	// x = 30

	*ptr = *ptr + 5;
	// *p = 30 + 5
	// *p = 35


	cout << *ptr << endl;

	cout << &*ptr << endl;



}