/*
Author-Udean Mbano
Date - 12/03/2015
Program uses the pointers and vurtual functions
*/
#include<iostream>
#include<string>
#include "petType.h"
#include "dogType.h"
using namespace std;
void callPrint(petType * p);
int main()
{
	petType *q; //Line 1
	dogType *r; //Line 2
	q = new petType("Lucky"); //Line 3
	r = new dogType("Tommy", "German Shepherd"); //Line 4
	/*C++ provides another operator called the member
		access operator arrow, ->.The operator -> consists of two consecutive symbols : a
		hyphen and the ��greater than�� sign
	*/
	q->print(); //Line 5
	cout << endl; //Line 6
	r->print(); //Line 7
	cout << "* * * Calling the function callPrint * * * "
		<< endl; //Line 8
	callPrint(q); //Line 9
	cout << endl; //Line 10
	callPrint(r); //Line 11
	cout << endl;

	cout << endl;
	r->setBreed("Siberian Husky ");
	cout << "* * * Calling Print using member arrow access operator * * * "
		<< endl; //Line 11
	cout << endl; //Line 6
	r->print(); //Line 7
	cout << endl; //Line 10
	cout << "* * * Calling the function callPrint * * * "
		<< endl; //Line 11
	callPrint(r); //Line 11
	cout << endl;

	return 0;
}
void callPrint(petType *p)
{
	p->print();
}