#include <iostream>
#include <string>

using namespace std;

//abstract  base class
class Shape{


	protected:
		string name;

	public:
		Shape(string s){
			name = s;
		}

		void setName(string s){
			name = s;
		}

		string getName() const{
			return name;
		}

		// pure virtual function
		virtual double getArea() const = 0;

	};

// first child class
class Circle : public Shape{
	double radius;

	public:
		Circle(string n, double r) : Shape(n) {
			radius = r;
		}

		void setRadius(double r){
			radius = r;
		}

		double getRadius () const{
			return radius;
		}

		virtual double getArea() const{
			return 3.14 * radius * radius;
		}

};

// second child class
class Rectangle : public Shape{

	double length, width;

	public:
		Rectangle(string n, double w, double l) : Shape(n) {
			width = w;
			length = l;
		}

		void setWidth(double w){
			width = w;
		}

		void setLength(double l){
			length = l;
		}

		double getWidth(){
			return this->width;
		}

		double getLength(){
			return this->length;
		}

		virtual double getArea()const{
			return this->length * this->width;
		}

};

// third child class
class Triangle : public Shape{

	double base, height;

	public:
		Triangle(string n, double h, double b) : Shape(n) {
			height = h;
			base = b;
		}

		void setHeight(double h){
			height = h;
		}

		void setBase(double b){
			base = b;
		}

		double getHeight(){
			return this->height;
		}

		double getBase(){
			return this->base;
		}

		virtual double getArea() const{
			return (0.5 * this->base) * this->height;
		}

};

int main(){

	Circle c("Circle", 3.1);
	cout << "The area of " << c.getName() << "( 3.14 * 2 * "<< c.getRadius() << " ) is : " << c.getArea() << endl;

	Rectangle r("Rectangle", 4.2 , 2.5);
	cout << "The area of " << r.getName() << "( "<< r.getWidth() << " x " << r.getLength() << " ) is : " << r.getArea() << endl;

	Triangle t("Triangle", 4 , 3);
	cout << "The area of " << t.getName() << "( 1/2 x "<< t.getBase() << " x " << t.getHeight() << " ) is : " << t.getArea() << endl;

	cout << endl << "===================================="<<endl;

	Shape* shapes[3] = {new Circle("Circle", 3.1), new Rectangle("Rectangle",4.2,2.5), new Triangle("Triangle",4,3)};
		for(int i= 0; i< 3; i++){
			cout << "The area of " << shapes[i]->getName() << " is : " << shapes[i]->getArea() << endl;
		}


	return 0;
}